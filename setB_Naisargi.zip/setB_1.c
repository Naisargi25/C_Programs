#include<stdio.h>
#include<string.h>

int main()
{
   int len,i,j;
   printf("Enter length of a string : ");
   scanf("%d",&len);
   char str[len];
   printf("Enter a string : ");
   scanf("%s",str);
   
  if(strlen(str)<=9)
  {
   for(i=0;i<len;i++)
   {
      if(str[i]==str[i+1])
      {
         for(j=i;str[j]!='\0';j++)
         {
            str[j]=str[j+2];
         }
         i=i-2;
         if(i<0)
         {
           i=-1;// because we want that iteration again start from 0 so... 
           len=strlen(str);
         }
      }
   }
  }
  else
  {
      printf("Length exceeded.\n"); 
      return 0;
  }
  
  if(strlen(str)==0)
  {
      printf("Empty String\n");
  }
  else
  {
      printf("After reduction string is :\n");
      printf("%s",str);
      printf("\n");
  }
   
   return 0;  
}

#include <stdio.h>
#include <string.h>

int main()
{   
    FILE *fdata;
    char son[100][100],father[100][100],grandfather[100];
    
    if ((fdata = fopen("file.txt", "r")) == NULL) 
    {
       printf("Error! File cannot be opened.");
    }
    
    for(int j=1;j<=5;j++)
    {
       while(fscanf(fdata,"%s %s",son[j],father[j])!=EOF) //scan data until End of file occurs
       {
          break;
       }
          
       printf("\n%s %s",son[j],father[j]); //stores the data into son array and father array and prints.
   }
    printf("\n");
    
    int grandchildren_count=0,fatherPos,i;
    printf("\nEnter the grandfather name : ");
    scanf("%s",grandfather);
    for(i=1;i<=5;i++)
    {
        if(strcmp(grandfather,father[i])==0)
        {
            fatherPos=i;
            for(int j=1;j<=5;j++)
            {
               if(strcmp(son[fatherPos],father[j])==0)
               {
                 grandchildren_count++;
               }

            }
        }
    }
    
    printf("%s has %d grandchildren\n",grandfather,grandchildren_count);
    return 0;
}

#include <stdio.h>

void reverseBits(int x)
{
   int i,a[100],len=0;
    
   //converting decimal into binary
   for(i=0;x>0;i++)    
   {    
      a[i]=x%2;    
      x=x/2;
      len++;
   }    
  
   printf("Before:");    
   for(i=i-1;i>=0;i--)    
   {    
      printf("%d",a[i]);    
   }    
  
   //printing binary value of given number in reverse order 
   printf("  After:");
   for(i=0;i<len;i++)    
   {    
       printf("%d",a[i]);    
   }
   printf("\n");
}

int main()
{
   int num;
   printf("Enter a number :\n");
   scanf("%d",&num);
 
   reverseBits(num);
    
   return 0;
}
